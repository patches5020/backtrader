"""Read-only: cdcx swing structure / BOS on CLOSED bars only, with timestamps.

Used by the 4H-close structure check (xrp_4h_status_prompt.md). Drops the still-forming
bar, then prints the swing sequence, the raw BOS flag, the strict BOS state, and the
0.25 x ATR confirmation level for the most recent labeled swing high and low.

    python closed_swings.py [SYMBOL] [TF ...]      e.g. python closed_swings.py XRP/USD 1h 4h
"""
import sys
import time
from datetime import datetime, timezone

from cdcx import bos_state as bos_state_module
from cdcx import structure_levels
from cdcx.config import settings
from cdcx.exchange.cryptocom import CryptoComExchange
from cdcx.indicators import atr_ema_variant1, market_structure

TF_SEC = {"1h": 3600, "4h": 14400, "1d": 86400, "1w": 604800}


def fmt(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%m-%d %H:%MZ")


def main(argv):
    symbol = argv[0] if argv and "/" in argv[0] else "XRP/USD"
    tfs = [a for a in argv if a in TF_SEC] or ["1h", "4h"]
    ex = CryptoComExchange(settings.cryptocom_api_key, settings.cryptocom_api_secret)
    now = time.time()
    print(f"closed-bar structure for {symbol} at {fmt(now)}")
    for tf in tfs:
        d = ex.fetch_ohlcv(symbol, timeframe=tf, limit=200)
        ts = [t / 1000 if t > 1e11 else t for t in d.timestamps]
        n = sum(1 for t in ts if t + TF_SEC[tf] <= now)  # bars whose close time has passed
        H, L, C, V = d.highs[:n], d.lows[:n], d.closes[:n], d.volumes[:n]
        r = market_structure.analyze(H, L, price=C[-1])
        bs = bos_state_module.classify_bos_state(r, H, L, C, V)
        atr = atr_ema_variant1.calculate_atr(H, L, C)[-1]
        margin = structure_levels.BREAKOUT_ATR_MULTIPLE * atr
        print(f"\n=== {tf}: {len(ts) - n} forming bar(s) dropped | last closed bar {fmt(ts[n - 1])} "
              f"O {d.opens[n - 1]} H {H[-1]} L {L[-1]} C {C[-1]}")
        print(f"swing sequence (last 4): {r.structure}")
        print(f"raw BOS flag (close vs latest labeled swing): {r.bos}")
        print(f"strict BOS state ({structure_levels.BREAKOUT_ATR_MULTIPLE} x ATR margin): "
              f"{bos_state_module.format_bos_state(bs)} | {'; '.join(bs.reasons)}")
        print(f"ATR({atr_ema_variant1.ATR_LENGTH}) {atr:.5f} -> margin {margin:.5f}")
        hi = [s for s in r.swings if s.kind == "high" and s.label]
        lo = [s for s in r.swings if s.kind == "low" and s.label]
        if hi:
            s = hi[-1]
            print(f"  bullish confirm: close > {s.price + margin:.4f}  (swing high {s.price:.4f} {s.label} @ {fmt(ts[s.index])})")
        if lo:
            s = lo[-1]
            print(f"  bearish confirm: close < {s.price - margin:.4f}  (swing low {s.price:.4f} {s.label} @ {fmt(ts[s.index])})")
        print("  last 8 swings (2-left/2-right fractal; confirmed 2 bars later):")
        for s in r.swings[-8:]:
            print(f"    {fmt(ts[s.index])}  {s.kind:4}  {s.price:.4f}  {s.label or '-':2}  "
                  f"confirmed {fmt(ts[min(s.index + 2, n - 1)])}")


if __name__ == "__main__":
    main(sys.argv[1:])
