Scheduled 4H-close CLOSED-CANDLE STRUCTURE CHECK for XRP/USD (monitor only -- there is no open cdcx trade to manage).
Run it start to finish without asking questions. (The open-trade version of this prompt is saved as
xrp_4h_status_prompt.open_trade.md -- if step 1 finds an OPEN XRP/USD trade, say so at the very top of the report.)

SHELL COMMANDS: run each command below EXACTLY as written, as its own Bash call, from the current directory.
Never prefix `cd`, never chain with `&&` / `;` / `|`, never redirect -- this headless session only allows the bare
commands (`cdcx-ai ...`, `python ...`, `wslpath ...`, `date ...`, `cat ...`, `ls ...`); anything else is denied.
cdcx-ai finds its trades file by absolute path (.env), so the current directory is fine.
Scratch dir for files: /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out

Snapshot rule: the analysis basis is the 4H candle that JUST closed and the last closed 1H candle. Always print both
candle timestamps (UTC). Anything computed with the still-forming candle is labelled "(provisional)".

1. `cdcx-ai --list-trades` -- report any OPEN XRP/USD paper trade (expected: none). Do NOT run --update-trades.
2. `python /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/closed_swings.py XRP/USD 1h 4h`
   -- closed bars only: swing sequence with timestamps, raw BOS flag, strict BOS state (0.25 x ATR margin), ATR,
   and the exact bullish/bearish confirmation levels. This is the authority for BOS; the raw flag alone is not
   confirmation.
3. `cdcx-ai --symbol XRP/USD --timeframes 1h,4h,1d,1w --structure-report` -- regime per timeframe (TRENDING /
   RANGING / TRANSITION), MTF table, VP hierarchy, prev-day AVWAP/AFVP block. Its per-timeframe sections include
   the forming candle -> label them provisional; the prev-day AVWAP block is closed-bar.
4. TradingView: `tv_health_check`. If it fails, retry once after ~20 s; if still down, report TV sections as
   "unknown" -- do NOT relaunch or close TradingView. Chart CRYPTOCOM:XRPUSD on 60 (1H). Closed 1H values: use
   `data_get_ohlcv` count=3 (the second-to-last bar is the last closed 1H; the last one is forming) and
   `data_get_study_values` (its last_bar_values belong to the FORMING bar -> provisional). Note the anchored VP VAL
   (Anchored volume profile "Developing VA Low") and the two Anchored VWAPs.
5. Read the previous structure-check report (newest trading/status/out/xrp_4h_status_*.txt) to say what changed.

Write the report as plain text (monospace), these sections:
HEADER: XRP/USD STRUCTURE CHECK | 4H candle <open-close UTC> closed | last closed 1H <time UTC> | monitor only
4H BOS: close vs the bullish confirmation level (swing high + 0.25 x ATR, with the ATR value) and the bearish level;
  strict BOS state before -> now; swing sequence + last 4 swings with timestamps.
1H STRUCTURE: swing sequence + last 4 swings with timestamps; strict BOS state; bullish/bearish confirmation levels;
  last closed 1H close vs anchored VP VAL (~1.3296 on 2026-10-20 -- use the current value) and vs Oct 19 AVWAP.
CONFLUENCE GATE: regime of 1H/4H/1D/1W; count of NON-transitional timeframes (need 2 of 4) and their direction ->
  gate OPEN/CLOSED. A confirmed 4H BOS alone does not open the gate.
VALUE / VWAP: price vs cdcx 1H VP, prev-day VP (VP-01..05 lines), AVWAP sigma position.
CHANGES SINCE LAST CHECK: what flipped (BOS state, swings, regimes, gate).
CONDITIONAL PATHWAYS: A/B/C with the exact trigger levels from steps 2-4 -- conditional, never a prediction.
KEY LEVELS (high -> low) | next check time (next 4H close + 4 min, in UTC and CDT).
TV PAPER ACCOUNT: one line from /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/tv_paper.json
  (open positions / working orders count; "unknown" if success is false or the file is missing). Observation only.

Do NOT send the report yourself: use the Write tool to save it to exactly
/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/report.txt -- the runner sends it to Telegram.
(Shell redirects like `> file` are blocked; run commands plainly and read their stdout.)

Chart: chart stays on 60 (1H). `chart_set_visible_range` from now - 5 days to now + 4h so the latest bar sits at the
right edge. `capture_screenshot` region=chart, wait_for_render=true. Read the image to confirm candles are visible;
fix the range and retake if not. Use the Write tool to save exactly two lines to
/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/chart.txt
  line 1: the screenshot's WSL path (convert the Windows path with wslpath)
  line 2: caption, e.g. XRP/USD 1H | 4H close ... | 4H BOS confirm > ... | gate CLOSED (n/4)

Rules (do not break):
- Monitor only. Never place, modify or cancel any order (cdcx or TradingView Paper Trading), never approve anything,
  never run --execute or --update-trades, never re-arm watchers, never edit code, config or risk parameters.
- NO TRADE = insufficient confirmation, not bearish. Pathways are conditional; never predict which one happens.
  ATR confirms, never triggers.
- A missing / unreadable data source is reported as "unknown", never guessed.
- Never print Telegram credentials. Send only via the runner (never read Telegram updates).
