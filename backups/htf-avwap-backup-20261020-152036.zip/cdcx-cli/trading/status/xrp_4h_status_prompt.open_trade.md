Scheduled 4H-close status check for the open XRP/USD PAPER trade. Run it start to finish without asking questions, then send the results to Telegram.

Working dir for cdcx commands: /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli
Scratch dir for files: /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out

1. `cdcx-ai --symbol XRP/USD --update-trades` and `cdcx-ai --list-trades`. If there is no OPEN XRP/USD trade, send
   `cdcx-telegram send "XRP/USD 4H check: no open paper trade"` (include any close reason / realized P&L) and stop.
   If a TP or the stop fired, or the trade closed, put that at the very top of the report.
2. `cdcx-ai --symbol XRP/USD --timeframes 1h,4h,1d,1w --structure-report` (read its stdout).
3. TradingView: `tv_health_check` (the runner has already launched TradingView if it was closed). If it still
   fails, retry once after ~20 s; if still down, report all TV sections as "unknown" -- do NOT relaunch or close
   TradingView yourself. Make sure the chart is CRYPTOCOM:XRPUSD on 240 (4H). Read `data_get_study_values` (use
   `last_bar_values`), `quote_get`, `data_get_ohlcv` with summary=true.
4. Read /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/alerts/xrp_bos_watch_state.json and
   xrp_bos_watch_config.json for fired / unfired BOS triggers.
5. TradingView PAPER TRADING account (the user's own, SEPARATE from the cdcx trade): read
   /mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/tv_paper.json (the runner already dumped it
   read-only). If success is false or the file is missing, report the section as "unknown".
6. Max adverse/favorable excursion since entry: low/high of Crypto.com XRP_USD 4h candles since the trade's opened_at
   (public get-candlestick API via python).

Write the report as plain text (monospace) with these sections, same layout as the earlier reports:
POSITION (entry, size, stop, TPs, TPs hit) | P&L / DRAWDOWN (unrealized $, %, R, % of account; max adverse and max
favorable since entry; cushion to stop; distance to TP1 and break-even; circuit breaker) | CDCX-AI VERDICT (1H/4H/1D/1W
regime, score, ADX, RSI, VOL, ATR state, ATR alignment, range setup) | INDICATORS (ATR, VOL, RSI, ADX, EMA, VWAP, FRVP,
AVP, cdcx VP hierarchy, FVG) | STRUCTURE (BOS, swings, BOS-watcher triggers, REVERSAL, POC BOUNCE, RETEST) |
TV PAPER ACCOUNT | ASSESSMENT | CONDITIONAL PATHWAYS A/B/C with trigger levels | KEY LEVELS | next check time.

TV PAPER ACCOUNT section (after STRUCTURE), labelled "TradingView Paper Trading -- user's account, separate from cdcx":
 - Open positions (or "none"), with unrealized P&L if shown.
 - The file lists live orders (bracket legs have parent_id; legs are "inactive" until the parent fills) -- it does not
   include cancelled/rejected history, so detect those by comparing with the previous report.
 - WORKING orders: side, type, qty, limit/stop price, attached TP / SL, leverage / margin / placed (if present), expires; distance
   from current price to the entry (% and in 4H ATRs); $ risk = |entry - SL| x qty and that as % of $1,000;
   reward:risk to the TP if one is set; note if it would trade against the cdcx LONG.
 - Orders that changed since the last report (filled / rejected / cancelled / new) -- compare with the previous
   report in trading/status/out/ (newest xrp_4h_status_*.txt); list rejected ones explicitly.
 - Account summary values only if present in the file; otherwise "summary unknown (panel collapsed)".
 Observations only -- never recommend cancelling, and never touch these orders.
Do NOT send the report yourself: use the Write tool to save it to exactly
/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/report.txt -- the runner script sends that
file to Telegram as monospace text after you finish. (Shell redirects like `> file` / `< file` are blocked; run
commands plainly and read their stdout.)

Chart: `chart_set_visible_range` from 1790100000 (before entry) to now + 4h so the latest bar sits at the right
edge (never leave the chart scrolled into empty future space). `capture_screenshot` region=chart, wait_for_render=true.
Read the image to confirm the candles are visible; if not, fix the range and retake. Do NOT send it yourself:
use the Write tool to save exactly two lines to
/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/out/chart.txt
  line 1: the screenshot's WSL path (convert the Windows path with wslpath)
  line 2: the caption, e.g. XRP/USD 4H | price ... | entry ..., stop ... | key levels
The runner sends the report first, then the chart.

Rules (do not break):
- The TradingView Paper Trading orders belong to the user: never cancel, modify or place them.
- PAPER trade only. Never place orders, never change the stop, size, TPs or any risk parameter, never edit code or config.
- NO TRADE = insufficient confirmation, not bearish. Pathways are conditional; never predict which one happens.
  ATR confirms, never triggers.
- A missing / unreadable data source is reported as "unknown", never guessed.
- Never print Telegram credentials. Send only via cdcx-telegram (never read Telegram updates).
