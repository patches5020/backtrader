#!/usr/bin/env bash
# One-time RQ12 reminder, by Windows Task Scheduler (task "cdcx RQ12 reminder", 2027-04-25 09:15 local).
# Send-only Telegram message -- never reads updates, runs nothing else.
set -u
export PATH="/home/patches5020/.local/bin:/mnt/c/Users/patch/my-trade/bin:$PATH"
LOG="/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli/trading/status/rq12_reminder.log"
cdcx-telegram send "RQ12 reminder (VP-04 on vwap-vp-3 (1m, TradingView-matched) vs vwap-vp-1 levels): the confirmatory period 2026-10-24 -> 2027-04-24 is over.
Ask Claude Code to run the single RQ12 fetch + analysis:
  python -m cdcx.backtest.vwap_vp_rq12 --fetch DIR --start 2026-10-24 --end 2027-04-24
  python -m cdcx.backtest.vwap_vp_rq12 --data DIR --start 2026-10-24 --end 2027-04-24
Run it once; the RQ12 text in .ai/SHARED/research_questions.md is frozen." >> "$LOG" 2>&1
echo "$(date -u +%FT%TZ) exit $?" >> "$LOG"
