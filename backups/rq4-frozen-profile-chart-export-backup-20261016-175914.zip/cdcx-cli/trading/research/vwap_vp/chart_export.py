"""Export live cdcx --vwap-vp 1H data (closed bars) to JSON and draw a PNG."""
import json, sys, time
from datetime import datetime, timezone
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from cdcx.exchange.cryptocom import CryptoComExchange
from cdcx.volume_profile.prev_day import prev_day_levels
from cdcx.volume_profile.vwap_confluence import classify, _closed_window
from cdcx.indicators import market_structure, fair_value_gap
from cdcx import bos_state as bsm, no_trade_gate

out_json, out_png, section_txt = sys.argv[1:4]
SYM, TF = "XRP/USD", "1h"
now = time.time()
d = CryptoComExchange().fetch_ohlcv(SYM, TF, 58)
lv = prev_day_levels(d, TF, now=now)
res = classify(lv, d)
ts, idx = _closed_window(lv, d)
n = idx[-1] + 1
H, L, C, O, V = (list(x[:n]) for x in (d.highs, d.lows, d.closes, d.opens, d.volumes))
T = [no_trade_gate.timestamp_to_seconds(t) for t in d.timestamps[:n]]
ms = market_structure.analyze(H, L, price=C[-1])
bos = bsm.classify_bos_state(ms, H, L, C, V)
sw_hi = next((s for s in reversed(ms.swings) if s.kind == "high"), None)
sw_lo = next((s for s in reversed(ms.swings) if s.kind == "low"), None)
gaps = [g for g in fair_value_gap.detect_fvgs(H, L, C) if not g.filled]
first = idx[0]
bars = [{"t": T[i], "o": O[i], "h": H[i], "l": L[i], "c": C[i], "v": V[i]} for i in range(first, n)]
vw, sg = lv.avwap.series, lv.avwap.sigma_series
section = open(section_txt).read()
data = {
    "symbol": SYM, "timeframe": TF, "generated": datetime.fromtimestamp(now, timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    "session_start": lv.session_start, "session_end": lv.session_end,
    "bars": bars, "vwap": vw, "sigma": sg,
    "levels": {"poc": lv.poc, "vah": lv.vah, "val": lv.val, "hvn": lv.hvn, "lvn": lv.lvn},
    "swing_high": sw_hi and {"t": T[sw_hi.index], "price": sw_hi.price, "label": sw_hi.label},
    "swing_low": sw_lo and {"t": T[sw_lo.index], "price": sw_lo.price, "label": sw_lo.label},
    "bos": {"state": bos.state, "direction": bos.direction, "level": bos.level_price},
    "fvgs": [{"t": T[g.index], "top": g.top, "bottom": g.bottom, "kind": g.kind} for g in gaps if T[g.index] >= lv.session_end],
    "condition": res.condition, "z": res.z,
    "setups": [{"code": s.code, "name": s.name, "state": s.state, "direction": s.direction, "detail": s.detail} for s in res.setups],
    "families": res.families, "family_detail": res.family_detail,
    "qualification": res.qualification, "qualification_direction": res.qualification_direction,
    "section": section,
}
json.dump(data, open(out_json, "w"), indent=1)

# ---------- PNG ----------
BG, FG, GRID = "#131722", "#d1d4dc", "#2a2e39"
fig, ax = plt.subplots(figsize=(14, 7.5), facecolor=BG)
ax.set_facecolor(BG)
xs = list(range(len(bars)))
for x, b in zip(xs, bars):
    col = "#26a69a" if b["c"] >= b["o"] else "#ef5350"
    ax.vlines(x, b["l"], b["h"], color=col, lw=1)
    ax.add_patch(Rectangle((x - 0.35, min(b["o"], b["c"])), 0.7, max(abs(b["c"] - b["o"]), 1e-5), color=col))
ax.plot(xs, vw, color="#2962ff", lw=2, label="AVWAP (prev-day anchor)")
for k, a in ((1, .9), (2, .6), (3, .35)):
    ax.plot(xs, [v + k * s for v, s in zip(vw, sg)], color="#42a5f5", lw=1, alpha=a, ls="--")
    ax.plot(xs, [v - k * s for v, s in zip(vw, sg)], color="#42a5f5", lw=1, alpha=a, ls="--")
    ax.text(xs[-1] + .6, vw[-1] + k * sg[-1], f"+{k}σ {vw[-1]+k*sg[-1]:.4f}", color="#42a5f5", fontsize=8, va="center")
    ax.text(xs[-1] + .6, vw[-1] - k * sg[-1], f"-{k}σ {vw[-1]-k*sg[-1]:.4f}", color="#42a5f5", fontsize=8, va="center")
t_end = next(i for i, b in enumerate(bars) if b["t"] >= lv.session_end)
ax.axvspan(-0.5, t_end - 0.5, color="#ffffff", alpha=0.03)
ax.axvline(t_end - 0.5, color="#787b86", lw=1, ls=":")
ax.text(1, max(H[first:]) , "PRIOR SESSION (profile frozen)", color="#787b86", fontsize=9, va="top")
ax.text(t_end + .5, max(H[first:]), "TODAY", color="#787b86", fontsize=9, va="top")
for name, price, col in (("VAH", lv.vah, "#f23645"), ("POC", lv.poc, "#ffeb3b"), ("VAL", lv.val, "#4caf50")):
    ax.axhline(price, color=col, lw=1.6)
    ax.text(-0.4, price, f" {name} {price:.5f} ", color=col, fontsize=9, va="center", fontweight="bold",
            bbox=dict(facecolor=BG, edgecolor=col, boxstyle="round,pad=0.2"), zorder=5)
ax.axhspan(lv.val, lv.vah, color="#ffeb3b", alpha=0.04)
for g in data["fvgs"]:
    gx = next(i for i, b in enumerate(bars) if b["t"] == g["t"])
    col = "#ef5350" if g["kind"] == "bearish" else "#26a69a"
    ax.add_patch(Rectangle((gx - 1, g["bottom"]), len(bars) - gx + 1, g["top"] - g["bottom"], color=col, alpha=0.13))
    ax.text(len(bars) - 1, (g["top"] + g["bottom"]) / 2, f"{g['kind']} FVG {g['bottom']:.4f}-{g['top']:.4f}", color=col, fontsize=7.5, va="center", ha="right")
for sw, col, word in ((data["swing_high"], "#26a69a", "bull BOS above"), (data["swing_low"], "#ef5350", "bear BOS below")):
    if sw and sw["t"] >= bars[0]["t"]:
        sx = next(i for i, b in enumerate(bars) if b["t"] == sw["t"])
        ax.hlines(sw["price"], sx, len(bars), color=col, lw=1, ls="-.")
        ax.text(len(bars) - 1, sw["price"], f"{word} {sw['price']:.4f}", color=col, fontsize=8, ha="right", va="bottom")
ticks = [i for i, b in enumerate(bars) if datetime.fromtimestamp(b["t"], timezone.utc).hour % 6 == 0]
ax.set_xticks(ticks, [datetime.fromtimestamp(bars[i]["t"], timezone.utc).strftime("%m-%d %H:%MZ") for i in ticks])
ax.tick_params(colors=FG, labelsize=8); ax.grid(color=GRID, lw=.5)
for s in ax.spines.values(): s.set_color(GRID)
ax.yaxis.tick_right()
ax.set_xlim(-0.5, len(bars) + 6)
qd = f" ({res.qualification_direction})" if res.qualification_direction else ""
ax.set_title(f"XRP/USD 1H  ·  prev-day AVWAP + AFVP (cdcx vwap-vp-1)  ·  {data['generated']}  ·  live data, closed bars",
             color=FG, fontsize=11, loc="left")
lines = [f"Condition {res.condition}  ·  last close {C[-1]:.4f} = {res.z:+.2f}σ"]
lines += [f"{s.code} {s.state}" + (f" {s.direction}" if s.direction else "") for s in res.setups]
lines += [f"structure: BOS {bos.state}", f"DECISION: {res.qualification}{qd}", "Execution: NOT AUTHORIZED"]
ax.text(0.01, 0.02, "\n".join(lines), transform=ax.transAxes, color=FG, fontsize=8.5, family="monospace", va="bottom",
        bbox=dict(facecolor="#1e222d", edgecolor=GRID, boxstyle="round,pad=0.5"))
fig.tight_layout(); fig.savefig(out_png, dpi=130, facecolor=BG)
print(json.dumps({"bars": len(bars), "fvgs": data["fvgs"], "swing_high": data["swing_high"], "swing_low": data["swing_low"],
                  "bos": data["bos"], "q": res.qualification, "vwap_last": vw[-1]}, indent=0))
