import time
from cdcx.exchange.cryptocom import CryptoComExchange
from cdcx.indicators.anchored_vwap import anchored_vwap
from cdcx.indicators import volume_profile_fixed as vpf
from cdcx.volume_profile.prev_day import prev_day_levels
A = 1792022400
ex = CryptoComExchange()
for tf, n in (("1h", 60), ("5m", 700)):
    d = ex.fetch_ohlcv("XRP/USD", tf, n)
    s = lambda t: t/1000 if t > 1e11 else t
    a = anchored_vwap(d.timestamps, d.opens, d.highs, d.lows, d.closes, d.volumes, A)
    print(f"[{tf}] AVWAP incl forming: vwap {a.vwap:.6f} sigma {a.sigma:.6f} bars {a.bars_used} last {s(d.timestamps[-1]):.0f}")
    for k,(lo,hi) in a.bands.items(): print(f"   ±{k}σ  {lo:.6f} / {hi:.6f}")
    idx = [i for i,t in enumerate(d.timestamps) if s(t) >= A]
    H=[d.highs[i] for i in idx]; L=[d.lows[i] for i in idx]; V=[d.volumes[i] for i in idx]
    print(f"   range hi {max(H):.4f} lo {min(L):.4f}")
    for b in (24, 400):
        h = vpf.build_volume_profile(H, L, V, buckets=b)
        poc, vah, val = vpf.calculate_poc_vah_val(h)
        print(f"   VP anchor->now {b:>3} rows: POC {poc:.4f} VAH {vah:.4f} VAL {val:.4f}")
    p = prev_day_levels(d, tf)
    print(f"   cdcx prev-day-only (24 rows): {p.status} POC {p.poc:.4f} VAH {p.vah:.4f} VAL {p.val:.4f}" if p.poc else f"   prev-day: {p.status} {p.reasons}")
