#!/usr/bin/env bash
# vwap-watch-1 hourly run, by Windows Task Scheduler (task "cdcx vwap-watch hourly").
# Monitor only: closed 1H bars of XRP/USD and XLM/USD -> journal + state in <trading>/vwap_watch.
# No --notify (journal only), no orders, no position reads. Not part of RQ6 (RQ6 replays frozen data).
set -u

CDCX="/mnt/c/Users/patch/my-trade/backtrader-repo/cdcx-cli"
LOG="$CDCX/trading/status/vwap_watch_hourly.log"
export PATH="/home/patches5020/.local/bin:/mnt/c/Users/patch/my-trade/bin:$PATH"
cd "$CDCX" || exit 1

{
  echo "=== $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  for sym in XRP/USD XLM/USD; do        # sequential: both share state.json
    python -m cdcx.volume_profile.vwap_watch --symbol "$sym" --timeframe 1h
    echo "exit $? ($sym)"
  done
} >> "$LOG" 2>&1
