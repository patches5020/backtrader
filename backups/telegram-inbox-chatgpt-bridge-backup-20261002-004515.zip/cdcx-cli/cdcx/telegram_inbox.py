"""
telegram_inbox.py
-----------------
A local SQLite copy of the Telegram messages the cdcx bot has ALREADY received,
plus the messages cdcx has sent (reports, charts, bot replies).

    inbound:  Telegram -> cdcx bot (TelegramReader, the single reader) -> Bot.handle_update
                       -> TelegramInbox.store_message ------------------.
    outbound: cdcx.telegram_send (send-only) -> Telegram returns the     |
              sent message -> TelegramInbox.store_outbound -------------+-> data/telegram_inbox.db
              -> InboxReader (read-only) -> cdcx.telegram_inbox_mcp -> Claude Code / ChatGPT

Telegram never delivers the bot's own messages to its reader, so without the
outbound copy the reports the bot sends would be invisible to the inbox.

This module never talks to Telegram and never sees the bot token: the writer
side only receives update dicts the bot hands it, and the reader side opens
the database read-only (`mode=ro` + `PRAGMA query_only`). Standard library only.

Only messages from allowlisted chats are stored -- Bot.handle_update drops
everything else before calling store_message.

WAL mode lets the MCP reader query while the bot is writing; the busy timeout
keeps a brief lock from turning into an error. All SQL is parameterized.
"""
from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path
from typing import Optional

INBOX_DB = Path(os.getenv("CDCX_TELEGRAM_INBOX_DB")
                or Path(__file__).resolve().parent.parent / "data" / "telegram_inbox.db")

BUSY_TIMEOUT_MS = 5000
MAX_LIMIT = 200
DEFAULT_UNREAD_HOURS = 24

SCHEMA = (
    """CREATE TABLE IF NOT EXISTS messages (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_update_id  INTEGER NOT NULL,
        telegram_message_id INTEGER NOT NULL,
        chat_id             INTEGER NOT NULL,
        user_id             INTEGER,
        username            TEXT,
        timestamp           INTEGER NOT NULL,  -- Telegram's message date (unix seconds, UTC)
        received_at         REAL    NOT NULL,  -- when the bot stored it (unix seconds, UTC)
        text                TEXT    NOT NULL,
        direction           TEXT    NOT NULL DEFAULT 'inbound',  -- 'inbound' (to the bot) | 'outbound' (sent by cdcx)
        UNIQUE (chat_id, telegram_message_id)
    )""",
    "CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages (timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_messages_chat_timestamp ON messages (chat_id, timestamp)",
)
# Added after the first release: inboxes created before it get the column on the writer's next start.
DIRECTION_MIGRATION = "ALTER TABLE messages ADD COLUMN direction TEXT NOT NULL DEFAULT 'inbound'"
DIRECTIONS = ("inbound", "outbound")

_BASE_COLUMNS = ("id, telegram_update_id, telegram_message_id, chat_id, user_id, username, "
                 "timestamp, received_at, text")


class TelegramInbox:
    """Writer, used only inside the cdcx bot process."""

    def __init__(self, path: Path = INBOX_DB):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = self._connect()
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            with conn:
                for stmt in SCHEMA:
                    conn.execute(stmt)
                if not _has_direction(conn):
                    conn.execute(DIRECTION_MIGRATION)
        finally:
            conn.close()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=BUSY_TIMEOUT_MS / 1000)
        conn.execute(f"PRAGMA busy_timeout={BUSY_TIMEOUT_MS}")
        return conn

    def store_message(self, update: dict, now: Optional[float] = None) -> bool:
        """Store the update's text message. True if newly stored, False if it
        has no text or (chat_id, telegram_message_id) is already stored."""
        message = update.get("message") or {}
        chat_id = (message.get("chat") or {}).get("id")
        text = message.get("text")
        if chat_id is None or not text or message.get("message_id") is None:
            return False
        sender = message.get("from") or {}
        received = time.time() if now is None else now
        conn = self._connect()
        try:
            with conn:
                cur = conn.execute(
                    "INSERT OR IGNORE INTO messages (telegram_update_id, telegram_message_id, chat_id, user_id, "
                    "username, timestamp, received_at, text) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (update.get("update_id"), message["message_id"], chat_id, sender.get("id"),
                     sender.get("username"), int(message.get("date") or received), received, text))
            return cur.rowcount == 1
        finally:
            conn.close()

    def store_outbound(self, message: dict, now: Optional[float] = None) -> bool:
        """Store a message cdcx SENT, as Telegram returned it (the `result` of
        sendMessage / sendPhoto / sendDocument). Photos and documents are
        stored as a one-line marker plus their caption. True if newly stored."""
        chat_id = (message.get("chat") or {}).get("id")
        if chat_id is None or message.get("message_id") is None:
            return False
        text = message.get("text") or ""
        if not text:
            caption = message.get("caption") or ""
            if message.get("photo"):
                text = f"[photo]\n{caption}" if caption else "[photo]"
            elif message.get("document"):
                name = (message.get("document") or {}).get("file_name") or "file"
                text = f"[document: {name}]\n{caption}" if caption else f"[document: {name}]"
            else:
                text = caption
        if not text:
            return False
        sender = message.get("from") or {}
        received = time.time() if now is None else now
        conn = self._connect()
        try:
            with conn:
                cur = conn.execute(
                    "INSERT OR IGNORE INTO messages (telegram_update_id, telegram_message_id, chat_id, user_id, "
                    "username, timestamp, received_at, text, direction) VALUES (0, ?, ?, ?, ?, ?, ?, ?, 'outbound')",
                    (message["message_id"], chat_id, sender.get("id"), sender.get("username"),
                     int(message.get("date") or received), received, text))
            return cur.rowcount == 1
        finally:
            conn.close()


def _has_direction(conn: sqlite3.Connection) -> bool:
    return any(row[1] == "direction" for row in conn.execute("PRAGMA table_info(messages)"))


class InboxError(Exception):
    pass


class InboxReader:
    """Strictly read-only view of the inbox. Never creates, alters or writes it."""

    def __init__(self, path: Path = INBOX_DB):
        self.path = Path(path)

    def _connect(self) -> sqlite3.Connection:
        if not self.path.exists():
            raise InboxError(f"no inbox yet at {self.path} -- it is created when the cdcx bot stores "
                             "its first message (run `python -m cdcx.telegram_bot`)")
        conn = sqlite3.connect(f"{self.path.resolve().as_uri()}?mode=ro", uri=True,
                               timeout=BUSY_TIMEOUT_MS / 1000)
        conn.execute("PRAGMA query_only=ON")
        conn.execute(f"PRAGMA busy_timeout={BUSY_TIMEOUT_MS}")
        conn.row_factory = sqlite3.Row
        return conn

    def _query(self, clauses: list[str], params: list, limit: int, direction: Optional[str] = None,
               newest_first: bool = True) -> list[dict]:
        """`clauses` are ANDed; every value in them is a `?` parameter."""
        limit = max(1, min(int(limit), MAX_LIMIT))
        if direction is not None and direction not in DIRECTIONS:
            raise InboxError(f"direction must be one of {', '.join(DIRECTIONS)} (or omitted for both)")
        order = "DESC" if newest_first else "ASC"
        conn = self._connect()
        try:
            # An inbox the bot has not migrated yet has no direction column: everything in it is inbound.
            has_direction = _has_direction(conn)
            columns = _BASE_COLUMNS + (", direction" if has_direction else ", 'inbound' AS direction")
            clauses, params = list(clauses), list(params)
            if direction is not None:
                if has_direction:
                    clauses.append("direction = ?")
                    params.append(direction)
                elif direction == "outbound":
                    return []
            where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
            rows = conn.execute(f"SELECT {columns} FROM messages {where} ORDER BY timestamp {order}, id {order} "
                                "LIMIT ?", (*params, limit)).fetchall()
        finally:
            conn.close()
        return [_row(r) for r in rows]

    def latest(self, limit: int = 1, direction: Optional[str] = None) -> list[dict]:
        return self._query([], [], limit, direction)

    def unread(self, since: Optional[float] = None, limit: int = 50, now: Optional[float] = None,
               direction: Optional[str] = None) -> list[dict]:
        """Messages received after `since` (unix seconds), oldest first. Without
        `since`, the last DEFAULT_UNREAD_HOURS. Nothing is marked read -- the
        caller keeps its own cutoff (pass back the newest `received_at`)."""
        if since is None:
            since = (time.time() if now is None else now) - DEFAULT_UNREAD_HOURS * 3600
        return self._query(["received_at > ?"], [float(since)], limit, direction, newest_first=False)

    def search(self, query: str, limit: int = 20, direction: Optional[str] = None) -> list[dict]:
        """Case-insensitive search, newest first. Every whitespace-separated word
        must appear (in any order); a hyphenated word also matches with a space,
        so "CDCX-AI" finds "CDCX AI"."""
        words = (query or "").split()
        if not words:
            raise InboxError("search query is empty")
        clauses, params = [], []
        for word in words:
            variants = list(dict.fromkeys([word, word.replace("-", " ")]))
            clauses.append("(" + " OR ".join(["text LIKE ? ESCAPE '\\'"] * len(variants)) + ")")
            params += [f"%{_escape_like(v)}%" for v in variants]
        return self._query(clauses, params, limit, direction)

    def history(self, limit: int = 50, before: Optional[float] = None, chat_id: Optional[int] = None,
                direction: Optional[str] = None) -> list[dict]:
        """Newest-first page of messages; pass the oldest `timestamp` seen as `before` for the next page."""
        clauses, params = [], []
        if before is not None:
            clauses.append("timestamp < ?")
            params.append(int(before))
        if chat_id is not None:
            clauses.append("chat_id = ?")
            params.append(int(chat_id))
        return self._query(clauses, params, limit, direction)


def _escape_like(text: str) -> str:
    return text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _row(r: sqlite3.Row) -> dict:
    d = dict(r)
    d["time_utc"] = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(d["timestamp"]))
    return d
