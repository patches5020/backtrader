"""
structure_report.py
--------------------
`--structure-report`: shows the actual range/market-structure picture --
regime, POC/VAH/VAL and where price sits relative to them, an FVG read,
swing structure + Break of Structure -- independent of --execute. This is
a READ, not a trade signal: it doesn't size a position, open a paper
trade, or say buy/sell. It exists for exactly the case that's most useful
for it -- "the market is ranging, what are the actual boundaries" -- but
prints the same picture regardless of regime, since knowing you're NOT in
a clean range is just as useful as the range levels themselves.

Named `--structure-report` (not `--structure`) to avoid colliding with
cli.py's own `--structure` flag, which is the richer 1W/1D/4H/1H
structural LONG/SHORT trigger system (structure_levels.py /
structure_strategy.py / setup_grade.py) -- a different, more elaborate
report this module deliberately doesn't duplicate. This one is for
cdcx-equity (Robinhood/Webull), which has no multi-role structural-trigger
system of its own yet; ported over from the equity-only fork rather than
reinventing it here.

Deliberately reuses regime.py / volume_profile_fixed.py / market_structure.py
/ fair_value_gap.py as-is; computes nothing new.

Also reports bos_state.py's classification of the swing-based BOS (see that
module's docstring for why the raw BOS flag alone can read "None" right
after a genuine break) -- informational only, same as everything else in
this report: it doesn't feed structure_strategy.py's LONG/SHORT triggers
or the confluence/execution gate.

Also reports vp_setup.py's classification of the current situation relative
to VAH/VAL/POC as POC Bounce / Value Area Reversal / Value Area Breakout /
None -- same informational-only status as the BOS state line above.
"""

from __future__ import annotations

from dataclasses import dataclass

from . import bos_state as bos_state_module
from . import regime as regime_module
from . import vp_setup as vp_setup_module
from .indicators import volume_profile_fixed, market_structure, fair_value_gap
from .engine import _round_price  # same significant-figure price rounding engine.py itself uses
from .utils.color import colorize_vah, colorize_poc, colorize_val


@dataclass
class StructureReport:
    symbol: str
    timeframe: str
    price: float
    regime: "regime_module.RegimeResult"
    vp: "volume_profile_fixed.VolumeProfileResult"
    structure: "market_structure.MarketStructureResult"
    fvgs: list  # fair_value_gap.FVG, all detected (filled and unfilled) -- see _format_fvg_line
    bos_state: "bos_state_module.BosState"
    vp_setup: "vp_setup_module.VpSetup"


def build_structure_report(
    symbol: str, timeframe: str, highs, lows, closes, volumes,
) -> StructureReport:
    price = closes[-1]
    regime_result = regime_module.analyze(highs, lows, closes, volumes, higher_timeframes_aligned=False)
    vp_result = volume_profile_fixed.analyze(highs, lows, volumes, price=price)
    structure_result = market_structure.analyze(highs, lows, price=price)
    fvgs = fair_value_gap.detect_fvgs(highs, lows, closes)
    bos_state_result = bos_state_module.classify_bos_state(structure_result, highs, lows, closes, volumes)
    vp_setup_result = vp_setup_module.classify_vp_setup(
        price, vp_result.poc, vp_result.vah, vp_result.val, highs, lows, closes, volumes,
    )
    return StructureReport(
        symbol=symbol, timeframe=timeframe, price=price,
        regime=regime_result, vp=vp_result, structure=structure_result, fvgs=fvgs,
        bos_state=bos_state_result, vp_setup=vp_setup_result,
    )


def _format_fvg_line(fvgs: list) -> str:
    """Most recent UNFILLED gap, either direction -- this report is a plain
    read of what's real on the chart, not a trade call, so (unlike
    fair_value_gap.score_fvg) it doesn't filter to only the gap aligned with
    trend direction."""
    unfilled = [g for g in fvgs if not g.filled]
    if not unfilled:
        return "FVG: No unfilled gap"
    gap = unfilled[-1]
    kind = "Bullish" if gap.kind == "bullish" else "Bearish"
    top, bottom = _round_price(gap.top), _round_price(gap.bottom)
    return f"FVG: {kind} gap [{bottom}, {top}], unfilled"


def _price_location(price: float, poc: float, vah: float, val: float) -> str:
    if price > vah:
        return "ABOVE the value area (beyond VAH) -- outside the accepted range"
    if price < val:
        return "BELOW the value area (beyond VAL) -- outside the accepted range"
    if price > poc:
        return "inside the value area, above POC"
    if price < poc:
        return "inside the value area, below POC"
    return "at POC"


def format_structure_report(report: StructureReport) -> str:
    bar = "=" * 55
    lines = [bar, f"MARKET STRUCTURE -- {report.symbol} {report.timeframe}".center(55), bar, ""]

    lines.append(f"REGIME: {report.regime.icon} {report.regime.label}")
    lines.append(f"  Trend: {report.regime.trend_score}/10   Range: {report.regime.range_score}/10")
    lines.append("")

    vp = report.vp
    price, poc, vah, val = _round_price(report.price), _round_price(vp.poc), _round_price(vp.vah), _round_price(vp.val)
    lines.append(f"PRICE:  {price}")
    lines.append(colorize_poc(f"POC:    {poc}   (point of control, yellow)"))
    lines.append(colorize_vah(f"VAH:    {vah}   (value area high, red)"))
    lines.append(colorize_val(f"VAL:    {val}   (value area low, green)"))
    lines.append(f"  -> price is {_price_location(report.price, vp.poc, vp.vah, vp.val)}")
    lines.append(vp_setup_module.format_vp_setup(report.vp_setup))
    lines.append("")

    if report.regime.regime == "ranging":
        range_width = vp.vah - vp.val
        pct_through = ((report.price - vp.val) / range_width * 100) if range_width else 0.0
        lines.append("RANGE (market is classified RANGING):")
        lines.append(f"  {colorize_val(f'{val}  <---- VAL')} ... {colorize_poc(f'POC {poc}')} ... {colorize_vah(f'VAH ---->  {vah}')}")
        lines.append(f"  Price is {pct_through:.0f}% through the range (0% = VAL, 100% = VAH)")
        lines.append("")
    elif report.regime.regime == "transitional":
        lines.append("Regime is TRANSITIONAL -- neither a clean range nor a clean trend right now.")
        lines.append("The POC/VAH/VAL levels above are still real, just don't read them as a settled range yet.")
        lines.append("")

    lines.append(_format_fvg_line(report.fvgs))
    lines.append("")

    st = report.structure
    lines.append(f"SWING STRUCTURE: {st.structure}")
    lines.append(f"BREAK OF STRUCTURE: {st.bos}")
    lines.append(bos_state_module.format_bos_state(report.bos_state))
    lines.append(bar)
    return "\n".join(lines)
